
<?php
$con=mysqli_connect("sql107.epizy.com","epiz_29104079","ZcwOewb65f28qx","epiz_29104079_shop");
if(!$con){
  die("Connection failed: " . mysqli_connect_error());
}
 ?>


 <?php
 $con=mysqli_connect("localhost","root","","shop");
 if(!$con){
   die("Connection failed: " . mysqli_connect_error());
 }
  ?>
