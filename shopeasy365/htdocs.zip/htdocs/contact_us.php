<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Shop Name</title>
<link rel="stylesheet" href="css/menus.css">
</head>
<body>
<h1>  we will reach shortly</h1>

</body>
</html>
